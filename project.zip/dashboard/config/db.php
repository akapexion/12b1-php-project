<?php

session_start();
session_regenerate_id(true);

$conn = mysqli_connect("localhost", "root", "", "market");
?> 