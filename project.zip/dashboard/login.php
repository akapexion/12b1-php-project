<?php
    include("config/db.php");

    if(isset($_POST['login'])){
        extract($_POST);

        $select_query = "SELECT * FROM users WHERE user_email = '$email' AND user_password = sha1('$password')";
        $execute = mysqli_query($conn, $select_query);
        // var_dump($execute);

        $count_users = mysqli_num_rows($execute);
        // echo $count_users;
        $getData = mysqli_fetch_array($execute);
        if($count_users > 0){

            $_SESSION['fName'] = $getData['user_fname'];
            $_SESSION['lName'] = $getData['user_lname'];
            $_SESSION['email'] = $getData['user_email'];
            $_SESSION['role'] = $getData['user_role'];

            if($getData['user_role'] == "admin"){

            echo "<script>
                alert('Login Successful');
                location.assign('index.php');
            </script>";
            }
            else {
                 echo "<script>
                alert('Login Successful');
                location.assign('../index.php');
            </script>";
            }
        }
        else {
            echo "<script>
                alert('Incorrect Credentials');
                location.assign('login.php');
            </script>";
        }
    }


//     require '../google-api/vendor/autoload.php';
// // Creating new google client instance
// $client = new Google_Client();
// // Enter your Client ID
// $client->setClientId('');
// // Enter your Client Secrect
// $client->setClientSecret('');
// // Enter the Redirect URL
// $client->setRedirectUri('');
// // Adding those scopes which we want to get (email & profile Information)
// $client->addScope("email");
// $client->addScope("profile");
// if(isset($_GET['code'])){
//     $token = $client->fetchAccessTokenWithAuthCode($_GET['code']);
//     if(!isset($token["error"])){
//         $client->setAccessToken($token['access_token']);
//         // getting profile information
//         $google_oauth = new Google_Service_Oauth2($client);
//         $google_account_info = $google_oauth->userinfo->get();
    
//         // Storing data into database
//         $id = mysqli_real_escape_string($conn, $google_account_info->id);
//         $full_name = mysqli_real_escape_string($conn, trim($google_account_info->name));
//         $email = mysqli_real_escape_string($conn, $google_account_info->email);
//         $profile_pic = mysqli_real_escape_string($conn, $google_account_info->picture);
//         // checking user already exists or not
//         $get_user = mysqli_query($conn, "SELECT `user_google_id` FROM `users` WHERE `user_google_id`='$id'");
//         if(mysqli_num_rows($get_user) > 0){
//             $_SESSION['login_id'] = $id; 
//             header('Location: ../index.php');
//             exit;
//         }
//         else{
//             // if user not exists we will insert the user
//             $insert = mysqli_query($conn, "INSERT INTO `users`(`user_google_id`,`user_fname`, `user_lname`, `user_email`,`user_profile_image`) VALUES('$id','$full_name', '---', '$email','$profile_pic')");
//             if($insert){
//                 $_SESSION['login_id'] = $id; 
//                 header('Location: ../index.php');
//                 exit;
//             }
//             else{
//                 echo "Sign up failed!(Something went wrong).";
//             }
//         }
//     }
//     else{
//         header('Location: login.php');
//         exit;
//     }
//     }

?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>SB Admin 2 - Login</title>

    <!-- Custom fonts for this template-->
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link
        href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"
        rel="stylesheet">

    <!-- Custom styles for this template-->
    <link href="css/sb-admin-2.min.css" rel="stylesheet">

</head>

<body class="bg-gradient-primary">

    <div class="container">

        <!-- Outer Row -->
        <div class="row justify-content-center">

            <div class="col-xl-10 col-lg-12 col-md-9">

                <div class="card o-hidden border-0 shadow-lg my-5">
                    <div class="card-body p-0">
                        <!-- Nested Row within Card Body -->
                        <div class="row">
                            <div class="col-lg-6 d-none d-lg-block bg-login-image"></div>
                            <div class="col-lg-6">
                                <div class="p-5">
                                    <div class="text-center">
                                        <h1 class="h4 text-gray-900 mb-4">Welcome Back!</h1>
                                    </div>
                                    <form class="user" method="POST">
                                        <div class="form-group">
                                            <input type="email" class="form-control form-control-user"
                                                id="exampleInputEmail" aria-describedby="emailHelp"
                                                placeholder="Enter Email Address..." name="email">
                                        </div>
                                        <div class="form-group">
                                            <input type="password" class="form-control form-control-user"
                                                id="exampleInputPassword" placeholder="Password" name="password">
                                        </div>
                                        <div class="form-group">
                                            <div class="custom-control custom-checkbox small">
                                                <input type="checkbox" class="custom-control-input" id="customCheck">
                                                <label class="custom-control-label" for="customCheck">Remember
                                                    Me</label>
                                            </div>
                                        </div>
                                        <button name="login" class="btn btn-primary btn-user btn-block">
                                            Login
                                        </button>
                                        <hr>
                                        <a href="<?php echo $client->createAuthUrl(); ?>" class="btn btn-google btn-user btn-block">
                                            <i class="fab fa-google fa-fw"></i> Login with Google
                                        </a>
                                        <a href="index.html" class="btn btn-facebook btn-user btn-block">
                                            <i class="fab fa-facebook-f fa-fw"></i> Login with Facebook
                                        </a>
                                    </form>
                                    <hr>
                                    <div class="text-center">
                                        <a class="small" href="forgot-password.html">Forgot Password?</a>
                                    </div>
                                    <div class="text-center">
                                        <a class="small" href="register.php">Create an Account!</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>

        </div>

    </div>

    <!-- Bootstrap core JavaScript-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Core plugin JavaScript-->
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Custom scripts for all pages-->
    <script src="js/sb-admin-2.min.js"></script>

</body>

</html>