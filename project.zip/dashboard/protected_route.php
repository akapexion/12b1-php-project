<?php

    include("config/db.php");

 if(!isset($_SESSION['email']) && !isset($_SESSION['login_id'])){
                        echo "<script>
                            location.assign('login.php');
                        </script>";
                    }




?>