
		<?php
			include("base/header.php");
		?>							
		<!-- START HOME -->
		<section  id="home" class="home_bg">	
			<div class="container">
				<div class="row">
					<div class="col-lg-6 col-sm-6 col-xs-12">	
						<div class="home_content">
							<h1>Purdue is the best choice for everyone!</h1>
							<p>It is a long established fact that reader will be distracted readable content of a page when.</p>						
						</div>
						<div class="home_btn">
							<a href="course.html" class="cta"><span>Explore Courses</span>
							  <svg width="13px" height="10px" viewBox="0 0 13 10">
								<path d="M1,5 L11,5"></path>
								<polyline points="8 1 12 5 8 9"></polyline>
							  </svg>
							</a>
						</div>		
					</div><!-- END COL-->
					<div class="col-lg-6 col-sm-6 col-xs-12">	
						<div class="home_me_img">
							<img src="assets/images/all-img/home-image.png" class="img-fluid" alt="" />
							<div class="home_ps">
								<img src="assets/images/icon/user2.svg" alt="" />
								<h2>7500+</h2>
								<span>Active student</span>
							</div>
							<div class="home_ps2">
								<img src="assets/images/icon/file2.svg" alt="" />
								<h2>4500+</h2>
								<span>Online Course</span>
							</div>
						</div>		
					</div><!-- END COL-->
				</div><!--- END ROW -->			
			</div><!--- END CONTAINER -->
		</section>
		<!-- END  HOME -->
	</div>
	<!-- END  TOP HEADER CLASS -->
	
	<!-- START COUNTER -->
	<section class="count_area counter_feature">
		<div class="container">
			<div class="row">
				<div class="col-lg-3 col-sm-6 col-xs-12">
					<div class="single-counter count_one">
						<span class="ti-folder sc_one"></span>
						<h2 class="counter-num">134</h2>
						<p>Our Online Course</p>
					</div>							
				</div>
				<div class="col-lg-3 col-sm-6 col-xs-12">
					<div class="single-counter count_two">
						<span class="ti-medall-alt sc_two"></span>
						<h2 class="counter-num">299</h2>
						<p>Academic Programs</p>
					</div>
				</div><!-- END COL -->
				<div class="col-lg-3 col-sm-6 col-xs-12">
					<div class="single-counter count_three">
						<span class="ti-id-badge sc_three"></span>
						<h2 class="counter-num">684</h2>
						<p>Certified Students</p>
					</div>
				</div><!-- END COL -->
				<div class="col-lg-3 col-sm-6 col-xs-12">
					<div class="single-counter count_four">
						<span class="ti-user sc_four"></span>
						<h2 class="counter-num">941</h2>
						<p>Enrolled Students</p>
					</div>
				</div><!-- END COL -->						
			</div><!--- END ROW -->
		</div><!--- END CONTAINER -->		
	</section>
	<!-- END COUNTER -->
	
	<!-- START ABOUT US HOME ONE -->
	<section class="ab_one section-padding">
		<div class="container">									
			<div class="row">								
				<div class="col-lg-6 col-sm-12 col-xs-12 wow fadeInUp" data-wow-duration="1s" data-wow-delay="0.2s" data-wow-offset="0">
					<div class="ab_img">
						<img src="assets/images/all-img/about1.png" class="img-fluid" alt="image">
						 <div class="wc_year">
							<h3><span>6k+</span> <br />Happy Clients</h3>
						</div> 
					</div>
				</div><!--- END COL -->					
				<div class="col-lg-6 col-sm-12 col-xs-12 wow fadeInUp" data-wow-duration="1s" data-wow-delay="0.1s" data-wow-offset="0">
					<div class="ab_content">
						<h2>Create, Learn & grow your skills from anywhere.</h2>
						<p>Lorem ipsum dolor sit amet, consectetur notted adipisicing elit sed do eiusmod tempor incididunt ut labore et simply.</p>
					</div>
					<div class="abmv">
						<i class="fa-regular fa-lightbulb"></i>
						<h4>Discover the joy of lifelong learning</h4>
						<p>Lorem ipsum dolor sit amet consectetur adipiscing elit sed do eiusmod tempor ut labore.</p>
					</div>	
					<div class="abmv">
						<i class="fa-solid fa-satellite-dish"></i>
						<h4>Build a real community</h4>
						<p>Lorem ipsum dolor sit amet consectetur adipiscing elit sed do eiusmod tempor ut labore.</p>
					</div>	
					<div class="cta_two">
						<a href="#" class="cta"><span>Discover More</span>
						  <svg width="13px" height="10px" viewBox="0 0 13 10">
							<path d="M1,5 L11,5"></path>
							<polyline points="8 1 12 5 8 9"></polyline>
						  </svg>
						</a>
					</div>
				</div><!--- END COL -->																  
			</div><!--- END ROW -->
		</div><!--- END CONTAINER -->
	</section>
	<!-- END ABOUT US HOME ONE -->	
	
	<!-- START TOP PROMO FEATURES -->
	<section class="tp_feature section-padding">
	   <div class="container">							
			<div class="section-title text-center">
				<h4>Start Learning </h4>
				<h1>Build Better skills, faster From Today.</h1>
			</div>					
			<div class="row">					
				<div class="col-lg-3 col-sm-6 col-xs-12 wow fadeInUp" data-wow-duration="1s" data-wow-delay="0.4s" data-wow-offset="0">
					<div class="single_tp">
						<h3>Award Wining</h3>
						<i class="fa-solid fa-medal"></i>
						<p>Lorem ipsum dolor sit amet consectetur notted adipisicing elit.</p>
						<a href="about.html" class="cta"><span>Learn More</span>
						  <svg width="13px" height="10px" viewBox="0 0 13 10">
							<path d="M1,5 L11,5"></path>
							<polyline points="8 1 12 5 8 9"></polyline>
						  </svg>
						</a>
					</div>
				</div><!-- END COL -->				
				<div class="col-lg-3 col-sm-6 col-xs-12 wow fadeInUp" data-wow-duration="1s" data-wow-delay="0.2s" data-wow-offset="0">
					<div class="single_tp st_one">
						<h3>Quality Education</h3>
						<i class="fa-solid fa-book-journal-whills"></i>
						<p>Lorem ipsum dolor sit amet consectetur notted adipisicing elit. </p>
						<a href="about.html" class="cta"><span>Learn More</span>
						  <svg width="13px" height="10px" viewBox="0 0 13 10">
							<path d="M1,5 L11,5"></path>
							<polyline points="8 1 12 5 8 9"></polyline>
						  </svg>
						</a>
					</div>
				</div><!-- END COL -->			
				<div class="col-lg-3 col-sm-6 col-xs-12 wow fadeInUp" data-wow-duration="1s" data-wow-delay="0.3s" data-wow-offset="0">
					<div class="single_tp st_two">
						<h3>Expert Teachers</h3>
						<i class="fa-solid fa-user-graduate"></i>
						<p>Lorem ipsum dolor sit amet consectetur notted adipisicing elit.</p>
						<a href="about.html" class="cta"><span>Learn More</span>
						  <svg width="13px" height="10px" viewBox="0 0 13 10">
							<path d="M1,5 L11,5"></path>
							<polyline points="8 1 12 5 8 9"></polyline>
						  </svg>
						</a>
					</div>
				</div><!-- END COL -->			
				<div class="col-lg-3 col-sm-6 col-xs-12 wow fadeInUp" data-wow-duration="1s" data-wow-delay="0.4s" data-wow-offset="0">
					<div class="single_tp st_three">
						<h3>Life Time Support</h3>
						<i class="fa-solid fa-headset"></i>
						<p>Lorem ipsum dolor sit amet consectetur notted adipisicing elit.</p>
						<a href="about.html" class="cta"><span>Learn More</span>
						  <svg width="13px" height="10px" viewBox="0 0 13 10">
							<path d="M1,5 L11,5"></path>
							<polyline points="8 1 12 5 8 9"></polyline>
						  </svg>
						</a>
					</div>
				</div><!-- END COL -->							
			</div><!-- END ROW -->
		</div><!-- END CONTAINER -->
	</section>
	<!-- END TOP PROMO FEATURES -->		

	<!-- START TOPIC-->
	<section class="topic_content_p2 section-padding">
	   <div class="container">
			<div class="section-title">
				<h4>Start Learning </h4>
				<h1>Popular Categories From Today.</h1>
			</div>		
			<div class="row">									
				<div class="col-lg-3 col-sm-6 col-xs-12">
					<div class="single_tca sc_one">
						<img src="assets/images/icon/ct1.svg" alt="" />
						<h2><a href="#">IT & Software</a></h2>
						<span>71 Courses</span>
					</div>					
				</div><!-- END COL -->							
				<div class="col-lg-3 col-sm-6 col-xs-12">
					<div class="single_tca sc_two">
						<img src="assets/images/icon/ct2.svg" alt="" />
						<h2><a href="#">Digital Program</a></h2>
						<span>59 Courses</span>
					</div>					
				</div><!-- END COL -->							
				<div class="col-lg-3 col-sm-6 col-xs-12">
					<div class="single_tca sc_three">
						<img src="assets/images/icon/ct3.svg" alt="" />
						<h2><a href="#">Finance Marketing</a></h2>
						<span>68 Courses</span>
					</div>					
				</div><!-- END COL -->							
				<div class="col-lg-3 col-sm-6 col-xs-12">
					<div class="single_tca sc_four">
						<img src="assets/images/icon/ct4.svg" alt="" />
						<h2><a href="#">Modern Physics</a></h2>
						<span>83 Courses</span>
					</div>					
				</div><!-- END COL -->							
				<div class="col-lg-3 col-sm-6 col-xs-12">
					<div class="single_tca sc_five">
						<img src="assets/images/icon/ct5.svg" alt="" />
						<h2><a href="#">Music Production</a></h2>
						<span>37 Courses</span>
					</div>					
				</div><!-- END COL -->							
				<div class="col-lg-3 col-sm-6 col-xs-12">
					<div class="single_tca sc_six">
						<img src="assets/images/icon/ct6.svg" alt="" />
						<h2><a href="#">Website Design</a></h2>
						<span>51 Courses</span>
					</div>					
				</div><!-- END COL -->					
				<div class="col-lg-3 col-sm-6 col-xs-12">
					<div class="single_tca sc_seven">
						<img src="assets/images/icon/ct6.svg" alt="" />
						<h2><a href="#">UI/UX Design</a></h2>
						<span>38 Courses</span>
					</div>					
				</div><!-- END COL -->					
				<div class="col-lg-3 col-sm-6 col-xs-12">
					<div class="single_tca sc_eight">
						<img src="assets/images/icon/ct6.svg" alt="" />
						<h2><a href="#">Health & Fitness</a></h2>
						<span>43 Courses</span>
					</div>					
				</div><!-- END COL -->	
				<div class="col-lg-12 text-center">
					<div class="cc_btn">
						<a href="#" class="cta"><span>View All category</span>
						  <svg width="13px" height="10px" viewBox="0 0 13 10">
							<path d="M1,5 L11,5"></path>
							<polyline points="8 1 12 5 8 9"></polyline>
						  </svg>
						</a>
					</div>
				</div><!--END COL -->					
			</div><!-- END ROW -->
		</div><!-- END CONTAINER -->
	</section>
	<!-- END TOPIC -->		

	<!-- START WHY CHOOSE US-->
	<section class="marketing_content_area section-padding">
	   <div class="container">
			<div class="section-title">
				<h4>Why Choose Purdue</h4>
				<h1>Find the best features of Purdue.</h1>
			</div>		
			<div class="row">									
				<div class="col-lg-4 col-sm-6 col-xs-12 wow fadeInUp" data-wow-duration="1s" data-wow-delay="0.1s" data-wow-offset="0">
					<div class="single_feature_one">
						<div class="sf_top">
							<i class="fa-solid fa-school"></i>
							<h2><a href="about.html">Learn More <br />Anywhere</a></h2>
						</div>
						<p>The results with a friend who couldn’t believe it was written by an AI. is worth every Yaley and then some.</p>
						<a href="about.html">Read More <i class="fa-solid fa-arrow-right"></i></a>
					</div>					
				</div><!-- END COL -->								
				<div class="col-lg-4 col-sm-6 col-xs-12 wow fadeInUp" data-wow-duration="1s" data-wow-delay="0.2s" data-wow-offset="0">
					<div class="single_feature_one">
						<div class="sf_top">
							<i class="fa-solid fa-person-chalkboard"></i>
							<h2><a href="about.html">Expert <br />Instructor</a></h2>
						</div>	
						<p>The results with a friend who couldn’t believe it was written by an AI. is worth every Yaley and then some.</p>
						<a href="about.html">Read More <i class="fa-solid fa-arrow-right"></i></a>
					</div>					
				</div><!-- END COL -->								
				<div class="col-lg-4 col-sm-6 col-xs-12 wow fadeInUp" data-wow-duration="1s" data-wow-delay="0.3s" data-wow-offset="0">
					<div class="single_feature_one">
						<div class="sf_top">
							<i class="fa-solid fa-people-group"></i>
							<h2><a href="about.html">Team <br />Management</a></h2>
						</div>	
						<p>The results with a friend who couldn’t believe it was written by an AI. is worth every Yaley and then some.</p>
						<a href="about.html">Read More <i class="fa-solid fa-arrow-right"></i></a>
					</div>					
				</div><!-- END COL -->								
				<div class="col-lg-4 col-sm-6 col-xs-12 wow fadeInUp" data-wow-duration="1s" data-wow-delay="0.4s" data-wow-offset="0">
					<div class="single_feature_one">
						<div class="sf_top">
							<i class="fa-solid fa-book"></i>
							<h2><a href="about.html">Course <br />Planing</a></h2>
						</div>	
						<p>The results with a friend who couldn’t believe it was written by an AI. is worth every Yaley and then some.</p>
						<a href="about.html">Read More <i class="fa-solid fa-arrow-right"></i></a>
					</div>					
				</div><!-- END COL -->								
				<div class="col-lg-4 col-sm-6 col-xs-12 wow fadeInUp" data-wow-duration="1s" data-wow-delay="0.5s" data-wow-offset="0">
					<div class="single_feature_one">
						<div class="sf_top">
							<i class="fa-solid fa-chalkboard-user"></i>
							<h2><a href="about.html">Teacher <br />Monitoring</a></h2>
						</div>		
						<p>The results with a friend who couldn’t believe it was written by an AI. is worth every Yaley and then some.</p>
						<a href="about.html">Read More <i class="fa-solid fa-arrow-right"></i></a>
					</div>					
				</div><!-- END COL -->								
				<div class="col-lg-4 col-sm-6 col-xs-12 wow fadeInUp" data-wow-duration="1s" data-wow-delay="0.6s" data-wow-offset="0">
					<div class="single_feature_one">
						<div class="sf_top">
							<i class="fa-solid fa-ticket"></i>
							<h2><a href="about.html">24/7 Strong <br />Support</a></h2>
						</div>		
						<p>The results with a friend who couldn’t believe it was written by an AI. is worth every Yaley and then some.</p>
						<a href="about.html">Read More <i class="fa-solid fa-arrow-right"></i></a>
					</div>					
				</div><!-- END COL -->																
			</div><!-- END ROW -->
		</div><!-- END CONTAINER -->
	</section>
	<!-- END WHY CHOOSE US -->	
	
	<!--START COURSE -->
	<div class="best-course section-padding">
		<div class="container">
			<div class="section-title">
			  <h4>Popular Courses</h4>
			  <h1>Choose Our Top Courses</h1>
			</div>				
				<div class="course-list row wow fadeIn">
					<div class="col-xl-3 col-lg-4 col-md-6 col-12">
						<div class="course-item d-flex">
							<div class="course-inner">
								<div class="course-img">
									<img src="assets/images/course/c1.png" alt="course">
									<div class="course-price">$150</div>	
								</div>
								
								<div class="course-content">
									<div class="ccategory">
										<a href="#">Data Science</a>
									</div>
									
									<h3><a href="#">Professional Ceramic Moulding for Beginners</a></h3>
									
									<div class="crating">
									
										<i class="fa-solid fa-star"></i>
										<i class="fa-solid fa-star"></i>
										<i class="fa-solid fa-star"></i>
										<i class="fa-solid fa-star"></i>
										<i class="fa-solid fa-star"></i>
										
										<span>
											5.0 / 28 Rating
										</span>
									</div>
									
									<div class="cmeta">
										<span>
											<svg fill="none" viewBox="0 0 20 20"><path stroke="#2c7aff" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M14.376 6.25H3.126a.625.625 0 00-.626.625v8.75c0 .345.28.625.625.625h11.25c.346 0 .626-.28.626-.625v-8.75a.625.625 0 00-.625-.625z"/><path stroke="#2c7aff" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M5 3.75h11.875a.625.625 0 01.625.625v9.375"/></svg>
											 25 Lessons
										</span>		

										<span class="cmtime">
											<svg fill="none" viewBox="0 0 20 20"><path stroke="#2c7aff" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M10 5.625V10h4.375"/><path stroke="#2c7aff" stroke-miterlimit="10" stroke-width="1.5" d="M10 16.875a6.875 6.875 0 100-13.75 6.875 6.875 0 000 13.75z"/><path stroke="#2c7aff" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M15.303 2.045l2.652 2.652M2.045 4.697l2.652-2.652"/></svg>
											 8 Hours
										</span>
									</div>
									
								</div>
							</div>
							
							<div class="course-hover align-self-center">
								<div class="chover_content">
									<div class="ccategory">
										<a href="#">Data Science</a>
									</div>
									
									<h3><a href="#">Professional Ceramic Moulding for Beginners</a></h3>

									<div class="hcourse-price">$150.00</div>
									<p>	
										Lorem ipsum dolor sit amet consectur adipiscing elit sed eiusmod tempor.
									</p>								
									<div class="hcmeta">		
										<span>
											<img src="assets/images/all-img/avator.png" alt="img">
											<a href="#">Theme Ocean</a>							
										</span>	

										<span>
											<i class="fa-solid fa-star"></i>
											5.0 (2k)							
										</span>	
									</div>
									<div class="text-center">
										<a href="#" class="cta"><span>Enroll Now</span>
										  <svg width="13px" height="10px" viewBox="0 0 13 10">
											<path d="M1,5 L11,5"></path>
											<polyline points="8 1 12 5 8 9"></polyline>
										  </svg>
										</a>
									</div>
								</div>
							</div>
						</div>
					</div>					
					<!-- End course-item -->					
					
					<div class="col-xl-3 col-lg-4 col-md-6 col-12">
						<div class="course-item d-flex">
							<div class="course-inner">
								<div class="course-img">
									<img src="assets/images/course/c2.png" alt="course">
									<div class="course-price">$120</div>	
								</div>
								
								<div class="course-content">
									<div class="ccategory">
										<a href="#">Management</a>
									</div>
									
									<h3><a href="#">Ultimate Photoshop Training: From Beginner</a></h3>
									
									<div class="crating">
									
										<i class="fa-solid fa-star"></i>
										<i class="fa-solid fa-star"></i>
										<i class="fa-solid fa-star"></i>
										<i class="fa-solid fa-star"></i>
										<i class="fa-solid fa-star"></i>
										
										<span>
											5.0 / 28 Rating
										</span>
									</div>
									
									<div class="cmeta">
										<span>
											<svg fill="none" viewBox="0 0 20 20"><path stroke="#2c7aff" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M14.376 6.25H3.126a.625.625 0 00-.626.625v8.75c0 .345.28.625.625.625h11.25c.346 0 .626-.28.626-.625v-8.75a.625.625 0 00-.625-.625z"/><path stroke="#2c7aff" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M5 3.75h11.875a.625.625 0 01.625.625v9.375"/></svg>
											 25 Lessons
										</span>		

										<span class="cmtime">
											<svg fill="none" viewBox="0 0 20 20"><path stroke="#2c7aff" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M10 5.625V10h4.375"/><path stroke="#2c7aff" stroke-miterlimit="10" stroke-width="1.5" d="M10 16.875a6.875 6.875 0 100-13.75 6.875 6.875 0 000 13.75z"/><path stroke="#2c7aff" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M15.303 2.045l2.652 2.652M2.045 4.697l2.652-2.652"/></svg>
											 8 Hours
										</span>
									</div>
									
								</div>
							</div>
							
							<div class="course-hover align-self-center">
								<div class="chover_content">
									<div class="ccategory">
										<a href="#">Management</a>
									</div>
									
									<h3><a href="#">Ultimate Photoshop Training: From Beginner</a></h3>

									<div class="hcourse-price">$120.00</div>
									<p>	
										Lorem ipsum dolor sit amet consectur adipiscing elit sed eiusmod tempor.
									</p>								
									<div class="hcmeta">		
										<span>
											<img src="assets/images/all-img/avator.png" alt="img">
											<a href="#">Theme Ocean</a>							
										</span>	

										<span>
											<i class="fa-solid fa-star"></i>
											5.0 (2k)							
										</span>	
									</div>
									<div class="text-center">
										<a href="#" class="cta"><span>Enroll Now</span>
										  <svg width="13px" height="10px" viewBox="0 0 13 10">
											<path d="M1,5 L11,5"></path>
											<polyline points="8 1 12 5 8 9"></polyline>
										  </svg>
										</a>
									</div>
								</div>
							</div>
						</div>
					</div>					
					<!-- End course-item -->					
					
					<div class="col-xl-3 col-lg-4 col-md-6 col-12">
						<div class="course-item d-flex">
							<div class="course-inner">
								<div class="course-img">
									<img src="assets/images/course/c3.png" alt="course">
									<div class="course-price">$170</div>	
								</div>
								
								<div class="course-content">
									<div class="ccategory">
										<a href="#">Graphics</a>
									</div>
									
									<h3><a href="#">Basic Fundamentals of Interior & Graphics Design</a></h3>
									
									<div class="crating">
									
										<i class="fa-solid fa-star"></i>
										<i class="fa-solid fa-star"></i>
										<i class="fa-solid fa-star"></i>
										<i class="fa-solid fa-star"></i>
										<i class="fa-solid fa-star"></i>
										
										<span>
											5.0 / 28 Rating
										</span>
									</div>
									
									<div class="cmeta">
										<span>
											<svg fill="none" viewBox="0 0 20 20"><path stroke="#2c7aff" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M14.376 6.25H3.126a.625.625 0 00-.626.625v8.75c0 .345.28.625.625.625h11.25c.346 0 .626-.28.626-.625v-8.75a.625.625 0 00-.625-.625z"/><path stroke="#2c7aff" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M5 3.75h11.875a.625.625 0 01.625.625v9.375"/></svg>
											 25 Lessons
										</span>		

										<span class="cmtime">
											<svg fill="none" viewBox="0 0 20 20"><path stroke="#2c7aff" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M10 5.625V10h4.375"/><path stroke="#2c7aff" stroke-miterlimit="10" stroke-width="1.5" d="M10 16.875a6.875 6.875 0 100-13.75 6.875 6.875 0 000 13.75z"/><path stroke="#2c7aff" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M15.303 2.045l2.652 2.652M2.045 4.697l2.652-2.652"/></svg>
											 8 Hours
										</span>
									</div>
									
								</div>
							</div>
							
							<div class="course-hover align-self-center">
								<div class="chover_content">
									<div class="ccategory">
										<a href="#">Graphics</a>
									</div>
									
									<h3><a href="#">Basic Fundamentals of Interior & Graphics Design</a></h3>

									<div class="hcourse-price">$170.00</div>
									<p>	
										Lorem ipsum dolor sit amet consectur adipiscing elit sed eiusmod tempor.
									</p>								
									<div class="hcmeta">		
										<span>
											<img src="assets/images/all-img/avator.png" alt="img">
											<a href="#">Theme Ocean</a>							
										</span>	

										<span>
											<i class="fa-solid fa-star"></i>
											5.0 (2k)							
										</span>	
									</div>
									<div class="text-center">
										<a href="#" class="cta"><span>Enroll Now</span>
										  <svg width="13px" height="10px" viewBox="0 0 13 10">
											<path d="M1,5 L11,5"></path>
											<polyline points="8 1 12 5 8 9"></polyline>
										  </svg>
										</a>
									</div>
								</div>
							</div>
						</div>
					</div>					
					<!-- End course-item -->					
					
					<div class="col-xl-3 col-lg-4 col-md-6 col-12">
						<div class="course-item d-flex">
							<div class="course-inner">
								<div class="course-img">
									<img src="assets/images/course/c4.png" alt="course">
									<div class="course-price">$140</div>	
								</div>
								
								<div class="course-content">
									<div class="ccategory">
										<a href="#">Development</a>
									</div>
									
									<h3><a href="#">WordPress for Beginners – Master WordPress</a></h3>
									
									<div class="crating">
									
										<i class="fa-solid fa-star"></i>
										<i class="fa-solid fa-star"></i>
										<i class="fa-solid fa-star"></i>
										<i class="fa-solid fa-star"></i>
										<i class="fa-solid fa-star"></i>
										
										<span>
											5.0 / 28 Rating
										</span>
									</div>
									
									<div class="cmeta">
										<span>
											<svg fill="none" viewBox="0 0 20 20"><path stroke="#2c7aff" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M14.376 6.25H3.126a.625.625 0 00-.626.625v8.75c0 .345.28.625.625.625h11.25c.346 0 .626-.28.626-.625v-8.75a.625.625 0 00-.625-.625z"/><path stroke="#2c7aff" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M5 3.75h11.875a.625.625 0 01.625.625v9.375"/></svg>
											 25 Lessons
										</span>		

										<span class="cmtime">
											<svg fill="none" viewBox="0 0 20 20"><path stroke="#2c7aff" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M10 5.625V10h4.375"/><path stroke="#2c7aff" stroke-miterlimit="10" stroke-width="1.5" d="M10 16.875a6.875 6.875 0 100-13.75 6.875 6.875 0 000 13.75z"/><path stroke="#2c7aff" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M15.303 2.045l2.652 2.652M2.045 4.697l2.652-2.652"/></svg>
											 8 Hours
										</span>
									</div>
									
								</div>
							</div>
							
							<div class="course-hover align-self-center">
								<div class="chover_content">
									<div class="ccategory">
										<a href="#">Development</a>
									</div>
									
									<h3><a href="#">WordPress for Beginners – Master WordPress</a></h3>

									<div class="hcourse-price">$140.00</div>
									<p>	
										Lorem ipsum dolor sit amet consectur adipiscing elit sed eiusmod tempor.
									</p>								
									<div class="hcmeta">		
										<span>
											<img src="assets/images/all-img/avator.png" alt="img">
											<a href="#">Theme Ocean</a>							
										</span>	

										<span>
											<i class="fa-solid fa-star"></i>
											5.0 (2k)							
										</span>	
									</div>
									<div class="text-center">
										<a href="#" class="cta"><span>Enroll Now</span>
										  <svg width="13px" height="10px" viewBox="0 0 13 10">
											<path d="M1,5 L11,5"></path>
											<polyline points="8 1 12 5 8 9"></polyline>
										  </svg>
										</a>
									</div>
								</div>
							</div>
						</div>
					</div>					
					<!-- End course-item -->										
				</div><!--END ROW -->			
			</div><!--END CONTAINER -->		
		</div>
	<!--END COURSE -->	

	<!-- START VIDEO -->
	<section class="vid_area section-padding">
		<div class="container">																
			<div class="row">
				<div class="col-lg-6 col-sm-12 col-xs-12 wow fadeInUDown" data-wow-duration="1s" data-wow-delay="0.2s" data-wow-offset="0">
					<div class="video-area">
						<a href="https://www.youtube.com/watch?v=RXv_uIN6e-Y" class="magnific_popup video-button"><i class="fa fa-play"></i></a>
					</div>
				</div><!--- END COL -->
				<div class="col-lg-6 col-sm-12 col-xs-12 wow fadeInUp" data-wow-duration="1s" data-wow-delay="0.1s" data-wow-offset="0">
					<div class="cp_content">
						<h4>Best Online Learning Platform</h4>
						<h2>One Platfrom & Many Courses For You</h2>
						<p>From blogs to emails to ad copies, auto-generate catchy, original, and high-converting copies in popular tones languages.</p>
						<ul>
							<li><span class="ti-check"></span>9/10 Average Satisfaction Rate</li>
							<li><span class="ti-check"></span>96% Completitation Rate</li>
							<li><span class="ti-check"></span>Friendly Environment & Expert Teacher</li>
						</ul>
					</div>
					<div class="cp_btn">
						<a href="course.html" class="cta"><span>Explore Our Courses</span>
						  <svg width="13px" height="10px" viewBox="0 0 13 10">
							<path d="M1,5 L11,5"></path>
							<polyline points="8 1 12 5 8 9"></polyline>
						  </svg>
						</a>
					</div>
				</div><!--- END COL -->	
			</div><!--- END ROW -->
		</div><!--- END CONTAINER -->
	</section>
	<!-- END VIDEO -->		
	
	<!-- START TEAM-->
	<section class="team_member section-padding">
	   <div class="container">
			<div class="section-title">
				<h4>Our Instructor</h4>
				<h1>Our Expert Instructors</h1>
			</div>		
			<div class="row text-center">								
				<div class="col-lg-3 col-sm-6 col-xs-12 wow fadeInUp" data-wow-duration="1s" data-wow-delay="0.1s" data-wow-offset="0">
					<div class="our-team">
						<div class="team-content">
							<h3 class="title">Stephen Cronin</h3>
							<span class="post">Designer</span>
							<div class="sth_det2">
								<span class="ti-file"> <u>5 Course</u></span>
								<span class="ti-user"> <u>12 Student</u></span>
							</div>								
						</div>	
						<div class="team_img">
							<img src="assets/images/team/1.jpg" alt="team-image">
							<ul class="social">
								<li><a href="#" class="top_f_facebook"><i class="fa-brands fa-facebook"></i></a></li>
								<li><a href="#" class="top_f_twitter"><i class="fa-brands fa-x-twitter"></i></a></li>
								<li><a href="#" class="top_f_instagram"><i class="fa-brands fa-instagram"></i></a></li>
								<li><a href="#" class="top_f_linkedin"><i class="fa-brands fa-linkedin-in"></i></a></li>
							</ul>
						</div>
					
					</div>
				</div><!--- END COL -->														
				<div class="col-lg-3 col-sm-6 col-xs-12 wow fadeInUp" data-wow-duration="1s" data-wow-delay="0.2s" data-wow-offset="0">
					<div class="our-team">
						<div class="team_img">
							<img src="assets/images/team/2.jpg" alt="team-image">
							<ul class="social">
								<li><a href="#" class="top_f_facebook"><i class="fa-brands fa-facebook"></i></a></li>
								<li><a href="#" class="top_f_twitter"><i class="fa-brands fa-x-twitter"></i></a></li>
								<li><a href="#" class="top_f_instagram"><i class="fa-brands fa-instagram"></i></a></li>
								<li><a href="#" class="top_f_linkedin"><i class="fa-brands fa-linkedin-in"></i></a></li>
							</ul>
						</div>
						<div class="team-content">
							<h3 class="title">Rachel Park</h3>
							<span class="post">Developer</span>
							<div class="sth_det2">
								<span class="ti-file"> <u>19 Course</u></span>
								<span class="ti-user"> <u>41 Student</u></span>
							</div>								
						</div>
					</div>
				</div><!--- END COL -->
				<div class="col-lg-3 col-sm-6 col-xs-12 wow fadeInUp" data-wow-duration="1s" data-wow-delay="0.3s" data-wow-offset="0">
					<div class="our-team">
						<div class="team-content">
							<h3 class="title">Dan Billson</h3>
							<span class="post">Marketer</span>
							<div class="sth_det2">
								<span class="ti-file"> <u>14 Course</u></span>
								<span class="ti-user"> <u>33 Student</u></span>
							</div>								
						</div>
						<div class="team_img">
							<img src="assets/images/team/3.jpg" alt="team-image">
							<ul class="social">
								<li><a href="#" class="top_f_facebook"><i class="fa-brands fa-facebook"></i></a></li>
								<li><a href="#" class="top_f_twitter"><i class="fa-brands fa-x-twitter"></i></a></li>
								<li><a href="#" class="top_f_instagram"><i class="fa-brands fa-instagram"></i></a></li>
								<li><a href="#" class="top_f_linkedin"><i class="fa-brands fa-linkedin-in"></i></a></li>
							</ul>
						</div>
					</div>
				</div><!--- END COL -->
				<div class="col-lg-3 col-sm-6 col-xs-12 wow fadeInUp" data-wow-duration="1s" data-wow-delay="0.4s" data-wow-offset="0">
					<div class="our-team">
						<div class="team_img">
							<img src="assets/images/team/4.jpg" alt="team-image">
							<ul class="social">
								<li><a href="#" class="top_f_facebook"><i class="fa-brands fa-facebook"></i></a></li>
								<li><a href="#" class="top_f_twitter"><i class="fa-brands fa-x-twitter"></i></a></li>
								<li><a href="#" class="top_f_instagram"><i class="fa-brands fa-instagram"></i></a></li>
								<li><a href="#" class="top_f_linkedin"><i class="fa-brands fa-linkedin-in"></i></a></li>
							</ul>
						</div>
						<div class="team-content">
							<h3 class="title">Gina Mellow</h3>
							<span class="post">Co-founder</span>
							<div class="sth_det2">
								<span class="ti-file"> <u>11 Course</u></span>
								<span class="ti-user"> <u>27 Student</u></span>
							</div>								
						</div>
					</div>
				</div><!--- END COL -->																							
			</div><!-- END ROW -->
		</div><!-- END CONTAINER -->
	</section>
	<!-- END TEAM -->	
	
	<!-- START TESTIMONIALS-->
	<section class="testi_home_area section-padding">
	   <div class="container">
			<div class="section-title">
				<h4>Testimonial</h4>
				<h1>What users saying about Purdue</h1>
			</div>		
			<div class="row">								
				<div class="col-lg-12">
					<div id="testimonial-slider" class="owl-carousel">
						<div class="testimonial">
							<div class="testi_pic_title">
								<div class="pic">
									<img src="assets/images/all-img/t1.png" alt="">
								</div>
								<h4>Kallu Mastan</h4>
								<small class="post">Bissa Batpar</small>	
							</div>
							<p>I immediately shared the results with a friend who couldn’t believe it was written by an AI. is worth every Yaley and then some. Describe my business along with my business name.</p>													
							<i class="fa fa-star"></i>
							<i class="fa fa-star"></i>
							<i class="fa fa-star"></i>
							<i class="fa fa-star"></i>
							<i class="fa fa-star"></i>
						</div><!-- END TESTIMONIAL -->
						<div class="testimonial">
							<div class="testi_pic_title">
								<div class="pic">
									<img src="assets/images/all-img/t2.png" alt="">
								</div>
								<h4>Kader Kaku</h4>
								<small class="post">Mitthay Expert</small>	
							</div>
							<p>I immediately shared the results with a friend who couldn’t believe it was written by an AI. is worth every Yaley and then some. Describe my business along with my business name.</p>													
							<i class="fa fa-star"></i>
							<i class="fa fa-star"></i>
							<i class="fa fa-star"></i>
							<i class="fa fa-star"></i>
							<i class="fa fa-star"></i>							
						</div><!-- END TESTIMONIAL -->
						<div class="testimonial">
							<div class="testi_pic_title">
								<div class="pic">
									<img src="assets/images/all-img/t3.png" alt="">
								</div>
								<h4>Mittha Hasina</h4>
								<small class="post">Lotpat Company</small>	
							</div>							
							<p>I immediately shared the results with a friend who couldn’t believe it was written by an AI. is worth every Yaley and then some. Describe my business along with my business name.</p>													
							<i class="fa fa-star"></i>
							<i class="fa fa-star"></i>
							<i class="fa fa-star"></i>
							<i class="fa fa-star"></i>
							<i class="fa fa-star"></i>
						</div><!-- END TESTIMONIAL -->
						<div class="testimonial">
							<div class="testi_pic_title">
								<div class="pic">
									<img src="assets/images/all-img/t4.png" alt="">
								</div>
								<h4>Hasau Mahmud</h4>
								<small class="post">Mastan group</small>	
							</div>
							<p>I immediately shared the results with a friend who couldn’t believe it was written by an AI. is worth every Yaley and then some. Describe my business along with my business name.</p>													
							<i class="fa fa-star"></i>
							<i class="fa fa-star"></i>
							<i class="fa fa-star"></i>
							<i class="fa fa-star"></i>
							<i class="fa fa-star"></i>							
						</div><!-- END TESTIMONIAL -->
						<div class="testimonial">
							<div class="testi_pic_title">
								<div class="pic">
									<img src="assets/images/all-img/t1.png" alt="">
								</div>
								<h4>Kutta Leauge</h4>
								<small class="post">Kutta iNC</small>	
							</div>							
							<p>I immediately shared the results with a friend who couldn’t believe it was written by an AI. is worth every Yaley and then some. Describe my business along with my business name.</p>													
							<i class="fa fa-star"></i>
							<i class="fa fa-star"></i>
							<i class="fa fa-star"></i>
							<i class="fa fa-star"></i>
							<i class="fa fa-star"></i>
						</div><!-- END TESTIMONIAL -->
					</div><!-- END TESTIMONIAL SLIDER -->
				</div><!-- END COL  -->																							
			</div><!-- END ROW -->
		</div><!-- END CONTAINER -->
	</section>
	<!-- END TESTIMONIALS -->

	<!-- START BLOG -->
	<section id="blog" class="blog_area section-padding">
		<div class="container">
			<div class="section-title">
				<h4>News</h4>
				<h1>Our Latest Blogs</h1>
			</div>	
			<div class="row">		
				<div class="col-lg-4 col-sm-4 col-xs-12 wow fadeInUp" data-wow-duration="1s" data-wow-delay="0.1s" data-wow-offset="0">
					<div class="single_blog">
						<img src="assets/images/blog/1.jpg" class="img-fluid" alt="image" />
						<div class="img_info">
							<span>August 26, 2025 | <a href="blog_single.html">Education</a></span>
						</div>
						<div class="content_box">
							<h2><a href="blog_single.html">Professional Mobile Painting and Sculpting</a></h2>
							<a href="#" class="cta"><span>Read More</span>
							  <svg width="13px" height="10px" viewBox="0 0 13 10">
								<path d="M1,5 L11,5"></path>
								<polyline points="8 1 12 5 8 9"></polyline>
							  </svg>
							</a>								
						</div>
					</div>
				</div><!-- END COL-->				
				<div class="col-lg-4 col-sm-4 col-xs-12 wow fadeInUp" data-wow-duration="1s" data-wow-delay="0.1s" data-wow-offset="0">
					<div class="single_blog">
						<img src="assets/images/blog/2.jpg" class="img-fluid" alt="image" />
						<div class="img_info">
							<span>August 28, 2025 | <a href="blog_single.html">Design</a></span>
						</div>
						<div class="content_box">
							<h2><a href="blog_single.html">Professional Ceramic Moulding for Beginner</a></h2>
							<a href="#" class="cta"><span>Read More</span>
							  <svg width="13px" height="10px" viewBox="0 0 13 10">
								<path d="M1,5 L11,5"></path>
								<polyline points="8 1 12 5 8 9"></polyline>
							  </svg>
							</a>							
						</div>
					</div>
				</div><!-- END COL-->
				<div class="col-lg-4 col-sm-4 col-xs-12 wow fadeInUp" data-wow-duration="1s" data-wow-delay="0.3s" data-wow-offset="0">
					<div class="single_blog">
						<img src="assets/images/blog/3.jpg" class="img-fluid" alt="image" />
						<div class="img_info">
							<span>August 30, 2025 | <a href="blog_single.html">Marketing</a></span>
						</div>
						<div class="content_box">
							<h2><a href="blog_single.html">Education Is About Create Leaders For Tomorrow </a></h2>
							<a href="#" class="cta"><span>Read More</span>
							  <svg width="13px" height="10px" viewBox="0 0 13 10">
								<path d="M1,5 L11,5"></path>
								<polyline points="8 1 12 5 8 9"></polyline>
							  </svg>
							</a>
						</div>
					</div>
				</div><!-- END COL-->						
			</div><!-- / END ROW -->
		</div><!-- END CONTAINER  -->
	</section>	
	<!-- END BLOG -->		

	<!-- START INSTRUCTOR+FREE COURSE -->
	<section class="insfreecourse section-padding">
		<div class="container">									
			<div class="row">								
				<div class="col-lg-6 col-sm-12 col-xs-12 wow fadeInUp" data-wow-duration="1s" data-wow-delay="0.2s" data-wow-offset="0">
					<div class="single_ins">
						<div class="single_ins_content">
							<h4>Build Your Career</h4>
							<h1>Become an Instructor</h1>
							<p>Learn at your own pace, move the between multiple courses. </p>
							<a href="register.html" class="cta"><span>Apply Now</span>
							  <svg width="13px" height="10px" viewBox="0 0 13 10">
								<path d="M1,5 L11,5"></path>
								<polyline points="8 1 12 5 8 9"></polyline>
							  </svg>
							</a>
						</div>
						<div class="single_ins_img">
							<img src="assets/images/all-img/become-ins.png" class="img-fluid" alt="image">
						</div>
					</div>
				</div><!--- END COL -->				
				<div class="col-lg-6 col-sm-12 col-xs-12 wow fadeInUp" data-wow-duration="1s" data-wow-delay="0.2s" data-wow-offset="0">
					<div class="single_ins">
						<div class="single_ins_content">
							<h4>Build Your Career</h4>
							<h1>Get Free Courses</h1>
							<p>Learn at your own pace, move the between multiple courses. </p>
							<a href="register.html" class="cta"><span>Contact Us</span>
							  <svg width="13px" height="10px" viewBox="0 0 13 10">
								<path d="M1,5 L11,5"></path>
								<polyline points="8 1 12 5 8 9"></polyline>
							  </svg>
							</a>
						</div>
						<div class="single_ins_img">
							<img src="assets/images/all-img/free-course.png" class="img-fluid" alt="image">
						</div>
					</div>
				</div><!--- END COL -->								  
			</div><!--- END ROW -->
		</div><!--- END CONTAINER -->
	</section>
	<!-- END INSTRUCTOR+FREE COURSE -->			

	<!-- START NEWSLETTER -->
	<section class="newsletter_area section-padding">
		<div class="container">
			<div class="row text-center">			
				<div class="col-lg-6 offset-lg-3 col-sm-12 col-xs-12">
					<div class="subs_form">
						<h3>Subscripbe to our newsletter, We don't make any spam.</h3>
						<p>Lorem ipsum dolor sit amet consectetur adipisicing elitsed eiusmod tempor enim minim</p>
						<form action="#" class="home_subs">
							<input type="text" class="subscribe__input" placeholder="Enter your Email Address">
							<button type="button" class="subscribe__btn">Subscribe</button>
						</form>
					</div>
				</div><!-- END COL -->
			</div><!-- END ROW -->	
		</div><!--- END CONTAINER -->	
	</section>
	<!-- END NEWSLETTER -->	
	 <?php
			include("base/footer.php");
		?>
	
	